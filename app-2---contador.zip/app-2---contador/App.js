import React, { useState } from 'react';
import { View, Text, Button} from 'react-native';
import {styles} from './styles.js'

export default function App(){
  const [num, setNum] = useState(1)

  function somar() {
    setNum(num+1)
  }

   function subtrair() {
    setNum(num-1)
  }

  return(
    <View style={styles.area}>
    <Text style={styles.contador}>{num}</Text>    
    <Button style={styles.somar} title="+" color='green' onPress={() => somar()} />
    <Button styles={styles.subtrair} title="-" color='red' onPress={() => subtrair()} />
    </View>
  )
}
