import {StyleSheet} from 'react-native';




const styles = StyleSheet.create({
    area:{
      flex: 1,
    },
    contador:{
      height: 70,
      borderWidth: 1,
      borderColor: '#222',
      backgroundColor: 'silver',
      margin: 20,
      padding: 10,
      textAlign: 'center',
      fontSize: 25,
      fontWeight:'bold'
    },
    somar:{
      borderWidth: 1,
      borderColor: '#222',
      backgroundColor: 'green',
      margin: 20,
      padding: 10,
      textAlign: 'center',
      fontSize: 25,
      fontWeight:'bold'
    },
      subtrair:{
      borderWidth: 1,
      borderColor: '#222',
      backgroundColor: 'red',
      margin: 20,
      padding: 10,
      textAlign: 'center',
      fontSize: 25,
      fontWeight:'bold'
    }

  });




  export {styles};
