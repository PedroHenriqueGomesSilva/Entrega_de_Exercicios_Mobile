import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    area:{
      flex: 1,
    },
    result:{
      borderWidth: 1,
      borderColor: '#222',
      margin: 20,
      padding: 10,
      textAlign: 'center',
      fontSize: 25,
      fontWeight:'bold'
    },
    num:{
      borderWidth: 1,
      borderColor: '#222',
      margin: 20,
      padding: 10,
      textAlign: 'center',
      fontSize: 25,
      fontWeight:'bold'
    },
    x:{
      margin: 20,
      padding: 10,
      textAlign: 'center',
      fontSize: 25,
      fontWeight:'bold'

    },
    calcular:{
      borderWidth: 1,
      borderColor: '#222',
      backgroundColor: 'blue',
      margin: 20,
      padding: 10,
      textAlign: 'center',
      fontSize: 25,
      fontWeight:'bold'
    },
  });




  export {styles};