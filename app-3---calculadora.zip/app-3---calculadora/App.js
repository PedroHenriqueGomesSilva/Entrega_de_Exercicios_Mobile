import React, { useState } from 'react';
import { View, Text, Button, StyleSheet, TextInput} from 'react-native';
import {styles} from './styles.js'

export default function App(){
  const [num, setNum] = useState(0)
  const [num2, setNum2] = useState(0)
  const [result, setResult] = useState(0)


  return(
    <View style={styles.area}>
    <TextInput style={styles.num} onChangeText={setNum}/>
        <Text style={styles.x}> X </Text>
    <TextInput style={styles.num} onChangeText={setNum2}/>
    <Button style={styles.calcular} title="Calcular" onPress={() => setResult(num*num2)} />
   
    <Text style={styles.result}>{result}</Text>    
    </View>
  )
}
