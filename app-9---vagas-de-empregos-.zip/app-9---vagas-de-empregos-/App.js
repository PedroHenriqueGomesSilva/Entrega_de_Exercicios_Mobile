import React, { Component, useState } from 'react';
import { View, StyleSheet, Text, ScrollView, FlatList, Switch, TextInput, Button, Image} from 'react-native';
import {Picker} from '@react-native-picker/picker';
import Slider from '@react-native-community/slider';
import {styles} from './styles.js';

function App() {

let vagas = [
  {id: 1, cargo: 'Programador Back-End', salario: 5.000, desc: 'Programador Back-End', contato: '0000-0000'},
  {id: 1, cargo: 'Gerente de Projetos', salario: 15.000, desc: 'Gerente de equipe', contato: '0000-0000'},
  {id: 1, cargo: 'Engenheiro de Dados', salario: 20.000, desc: 'Engenheiro de Dados', contato: '0000-0000'},
  {id: 1, cargo: 'Zelador', salario: 1.000, desc: 'Zelador', contato: '0000-0000'},
]

const [feed, setFeed] = useState(vagas);

  return (
    <View style = {styles.container}>
    <Text style = {styles.text}> VAGAS </Text>
    <FlatList data={vagas} keyExtractor={(item) => item.id} renderItem={ ({item}) => <Vaga data={item}/>} />
    </View>
  );
}

export default App;

function Vaga(props){
    return(
    <View   style = {styles.vaga}>
      <Text> Cargo: {props.data.cargo} </Text>
      <Text> Salario: {props.data.salario} </Text>
      <Text> Descrição: {props.data.desc} </Text>
      <Text> Contato: {props.data.contato} </Text>
    </View>
  );

}
