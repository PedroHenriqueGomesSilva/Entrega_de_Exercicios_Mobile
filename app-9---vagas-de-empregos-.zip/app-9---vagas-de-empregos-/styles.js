import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    container:{
      flex: 1,
      textAlign: 'center'
    },
    vaga:{
      height: 200,
      borderColor: '#222',
      margin: 20,
      padding: 10,
      alignContent: 'center',
      fontSize: 25,
      fontWeight:'bold',
      borderWidth: 1,
    },
    image:{
    width: 100, 
    height: 100, 
    marginBottom: 10, 
    borderColor: 'silver', 
    borderWidth: 2, 
    backgroundColor: 'white' 
    },
    text:{
      textAlign: 'center',
      fontSize: 25,
      fontWeight:'bold'

    }
  });

  export {styles};