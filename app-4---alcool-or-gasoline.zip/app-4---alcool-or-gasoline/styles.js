import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    area:{
      flex: 1,
    },
    result:{
      borderWidth: 1,
      borderColor: '#222',
      margin: 20,
      padding: 10,
      textAlign: 'center',
      fontSize: 25,
      fontWeight:'bold'
    },
    num:{
      borderWidth: 1,
      borderColor: '#222',
      margin: 20,
      padding: 10,
      textAlign: 'center',
      fontSize: 25,
      fontWeight:'bold'
    },
    verificar:{
      borderWidth: 1,
      borderColor: '#222',
      backgroundColor: 'green',
      margin: 20,
      padding: 10,
      textAlign: 'center',
      fontSize: 25,
      fontWeight:'bold'
    },
    image:{
  width: 200, 
  height: 200, 
  marginLeft: 65, 
  marginBottom: 10, 
  borderColor: 'silver', 
  borderWidth: 10, 
  backgroundColor: 'white', 
  borderRadius: 30
}
  });




  export {styles};