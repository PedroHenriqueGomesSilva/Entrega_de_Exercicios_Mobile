import React, { useState } from 'react';
import { View, Text, Button, StyleSheet, TextInput, Image} from 'react-native';
import {styles} from './styles.js'

export default function App(){
  const [num, setNum] = useState(0)
  const [num2, setNum2] = useState(0)
  const [result, setResult] = useState(0)


  function calcular() {
    if(num / num2 < 0.7){
      setResult('Alcool');
    }
    else{
      setResult('Gasolina');
    }
  }


  return(
    <View style={styles.area}>
    <Image source={{ uri:'https://s1.static.brasilescola.uol.com.br/be/conteudo/images/a-gasolina-um-dos-principais-combustiveis-utilizados-pelo-ser-humano-em-seu-dia-dia-5a4f9e194b703.jpg'}} style={styles.image}/>
    <TextInput style={styles.num} placeholder="Preço do Alcool" onChangeText={setNum}/>
    <TextInput style={styles.num} placeholder="Preço da Gasolina" onChangeText={setNum2}/>
    <Button style={styles.verificar} color='green' title="Verificar" onPress={() => calcular()} />
   
    <Text style={styles.result}>{result}</Text>    
    </View>
  )
}
