import React, { Component, useState } from 'react';
import { View, StyleSheet, Text, ScrollView, FlatList, Switch, TextInput, Button, Image} from 'react-native';
import {Picker} from '@react-native-picker/picker';
import Slider from '@react-native-community/slider';
import {styles} from './styles.js';

function App() {
  return (
    <View style = {styles.container}>
    <Text style = {styles.text}> ANUNCIOS </Text>
    <ScrollView horizontal = {true} showsHorizontalScrollIndicator = {true} >

    <View style = {styles.anuncio}> 
    <Image source={{ uri:'https://lartbr.com.br/wp-content/uploads/2023/01/IMG_3351.jpg'}} style={styles.image}/>
    <Text> Fusca </Text>
    <Text> Preço: 10.000 </Text>
    </View>

     <View style = {styles.anuncio}> 
    <Image source={{ uri:'https://lartbr.com.br/wp-content/uploads/2023/01/IMG_3351.jpg'}} style={styles.image}/>
    <Text> Fusca </Text>
    <Text> Preço: 10.000 </Text>
    </View>
    
    <View style = {styles.anuncio}> 
    <Image source={{ uri:'https://lartbr.com.br/wp-content/uploads/2023/01/IMG_3351.jpg'}} style={styles.image}/>
    <Text> Fusca </Text>
    <Text> Preço: 10.000 </Text>
    </View>

    <View style = {styles.anuncio}> 
    <Image source={{ uri:'https://lartbr.com.br/wp-content/uploads/2023/01/IMG_3351.jpg'}} style={styles.image}/>
    <Text> Fusca </Text>
    <Text> Preço: 10.000 </Text>
    </View>
    </ScrollView>

    </View>
  );
}

export default App;
