import {StyleSheet} from 'react-native';




const styles = StyleSheet.create({
    area:{
      flex: 1,
    },
    contador:{
      height: 50,
      borderColor: '#222',
      margin: 20,
      padding: 10,
      textAlign: 'center',
      fontSize: 25,
      fontWeight:'bold',
      borderBottomWidth: 1
    },
    rolar:{
      borderWidth: 1,
      borderColor: '#222',
      margin: 20,
      padding: 10,
      textAlign: 'center',
      fontSize: 25,
      fontWeight:'bold'
    },
    text:{
      height: 10,
      borderColor: '#222',
      margin: 20,
      padding: 10,
      textAlign: 'center',
      fontSize: 15,
      fontWeight:'bold'
    }

  });




  export {styles};