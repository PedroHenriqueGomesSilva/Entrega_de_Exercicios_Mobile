import React, { useState } from 'react';
import { View, Text, Button} from 'react-native';
import {styles} from './styles.js'

export default function App(){
  const [num, setNum] = useState(1)

  function rolar() {
    setNum(Math.floor(Math.random()*11))
  }


  return(
    <View style={styles.area}>
    <Text style={styles.text}>Pense em um Número de 1 a 10</Text>    
    <Text style={styles.contador}>{num}</Text>    
    <Button style={styles.rolar} title="Rolar" onPress={() => rolar()} />
    </View>
  )
}