import { View, Text, Image} from 'react-native';
import {styles} from './styles.js'
function Experiencia(){

return(
  <View>
  <Text style={styles.titulo}>EXPERIENCIA: . . . </Text>
  <Text style={styles.titulo}>PROJETOS: . . .</Text>
  </View>
)
}

export default Experiencia  
        