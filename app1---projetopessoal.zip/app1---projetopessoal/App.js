import { View, Text, Image} from 'react-native';
import {styles} from './styles.js';
import DadosPessoais from './dadosPessoais.js'
import Formacao from './formacao.js'
import Experiencia from './experiencia.js'
function App(){
  return(
     <View style={styles.area}>
        <Image
          source={{ uri:'https://cdn-icons-png.flaticon.com/512/189/189000.png'}}
          style={styles.image}
        />
       <DadosPessoais></DadosPessoais>
       <Formacao></Formacao>
       <Experiencia></Experiencia>
      </View>
  )
}




export default App;