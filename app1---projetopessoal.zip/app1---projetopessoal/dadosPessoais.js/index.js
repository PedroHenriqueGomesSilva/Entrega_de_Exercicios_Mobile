import { View, Text, Image} from 'react-native';
import {styles} from './styles.js'
function DadosPessoais(){

return(
  <View>
 <Text style={styles.titulo}>DADOS PESSOAIS:</Text>
   <Text style={styles.info}>Nome: Pedro Henrique Gomes da Silva </Text>
  <Text style={styles.info}>Idade: 20 Anos</Text>
  <Text style={styles.info}>Nacionalidade: Brasileiro</Text>
  </View>
)
}

export default DadosPessoais