import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
titulo:{
    marginVertical:10, 
    marginHorizontal:10, 
    color: 'white',
    fontWeight:'bold'
},
info:{
    marginVertical:10, 
    marginHorizontal:10, 
    color: 'white'
}

});

export {styles}