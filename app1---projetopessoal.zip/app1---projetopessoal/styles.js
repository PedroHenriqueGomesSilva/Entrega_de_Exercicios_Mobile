import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
area:{
  marginTop: 80,
backgroundColor: 'black'
},
image:{
  width: 200, 
  height: 200, 
  marginLeft: 65, 
  marginBottom: 10, 
  borderColor: 'silver', 
  borderWidth: 10, 
  backgroundColor: 'white', 
  borderRadius: 30
}

});

export {styles}
