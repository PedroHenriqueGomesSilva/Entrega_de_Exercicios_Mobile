import { View, Text, Image} from 'react-native';
import {styles} from './styles.js'
function Formacao(){

return(
  <View>
  <Text style={styles.titulo}>FORMAÇÃO: TÉCNICO EM ANÁLISE E DESENVOLVIMENTO DE SISTEMAS</Text>
  </View>
)
}

export default Formacao  
        
        
