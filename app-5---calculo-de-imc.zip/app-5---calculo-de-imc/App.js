import React, { useState } from 'react';
import { View, Text, Button, StyleSheet, TextInput, Image} from 'react-native';
import {styles} from './styles.js'

export default function App(){
  const [num, setNum] = useState(0)
  const [num2, setNum2] = useState(0)
  const [total, setTotal] = useState(0)
  const [result, setResult] = useState(0)


  function calcular() {
    setTotal(num / (num2 * num2));
    if(total < 18.5){
      setResult('Abaixo do Peso')
    }else if(total >= 18.5 && total <= 24.9){
      setResult('Peso Normal');
    }else if(total >= 25 && total <= 34.9){
      setResult('Obesidade Grau I');
    }else if(total >= 35 && total <= 39.9){
      setResult('Obesidade Grau II');
    }else if(total >= 40 ){
      setResult('Obesidade Grau III / Obesidade Mórbida');
    }
}


  return(
    <View style={styles.area}>
    <Image source={{ uri:'https://ichef.bbci.co.uk/news/640/cpsprodpb/15E02/production/_104620698_prmo_imc_br-nc.png'}} style={styles.image}/>
    <TextInput style={styles.num} placeholder="Peso" onChangeText={setNum}/>
    <TextInput style={styles.num} placeholder="Altura" onChangeText={setNum2}/>
    <Button style={styles.verificar} color='green' title="Verificar" onPress={() => calcular()} />
   
    <Text style={styles.result}>{result}</Text>    
    </View>
  )
}
