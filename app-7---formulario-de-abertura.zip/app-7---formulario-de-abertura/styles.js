import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({

titulo:{
  fontSize: 20,
  fontWeight: 'bold',
  textAlign: 'center',
},
label:{
  fontSize: 15,
  fontWeight: 'bold',
}

});

export {styles};