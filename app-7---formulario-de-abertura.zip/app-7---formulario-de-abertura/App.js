import React, { Component, useState } from 'react';
import { View, StyleSheet, Text, ScrollView, FlatList, Switch, TextInput, Button} from 'react-native';
import {Picker} from '@react-native-picker/picker';
import Slider from '@react-native-community/slider';
import {styles} from './styles.js';


function App() {

const [idade, setIdade] = useState(0)
const [sexo, setSexo] = useState("Masculino")
const [escolaridade, setEscolaridade] = useState("Fundametal")
const [limite, setLimite] = useState(0)
const [brasileiro, setBrasileiro] = useState(false)

const [confirmIdade, setConfirmIdade] = useState(0)
const [confirmSexo, setConfirmSexo] = useState(0)
const [confirmEscolaridade, setConfirmEscolaridade] = useState(0)
const [confirmLimite, setConfirmLimite] = useState(0)
const [confirmBrasileiro, setConfirmBrasileiro] = useState(false)

function confirmar(){
setConfirmIdade(idade)
setConfirmSexo(sexo)
setConfirmEscolaridade(escolaridade)
setConfirmLimite(limite)
setConfirmBrasileiro(brasileiro)
}

return (
  <View>
    <Text style={styles.titulo}>Abertura de Conta</Text>

    <Text style={styles.label}>Idade: </Text>
    <TextInput styles={styles.input} onChangeText={setIdade}/>

    <Text style={styles.label}>Sexo: </Text>


    <Picker selectedValue={sexo} onValueChange={ (itemValue,itemIndex) => setSexo(itemValue) }>
      <Picker.Item key={1} value={"Masculino"} label="Masculino" />
      <Picker.Item key={2} value={"Feminino"} label="Feminino" />
      <Picker.Item key={3} value={"Não-Binário"} label="Não-Binário" />
    </Picker>

    

    <Text style={styles.label}>Escolaridade: </Text>
    <Picker selectedValue={escolaridade} onValueChange={ (itemValue,itemIndex) => setEscolaridade(itemValue)}>
      <Picker.Item key={1} value={"Fundamental"} label="Fundamental" />
      <Picker.Item key={2} value={"Ensino Médio"} label="Ensino Médio" />
      <Picker.Item key={3} value={"Ensino Superior"} label="Ensino Superior" />
    </Picker>

    <Text style={styles.label}>Limite: </Text>
    <Slider
      minimumValue={0}
      maximumValue={200}
      onValueChange={ (valorSelecionado) => setLimite(valorSelecionado) }
      value={limite}
    />

    <Text style={styles.label}>Brasileiro: </Text>
      <Switch
      value={brasileiro}
      onValueChange={ (valorSwitch) => setBrasileiro(valorSwitch) }
      />

    <Button color='green' title="Confirmar" onPress={() => confirmar()} />

    <Text style={styles.titulo}>DADOS INFORMADOS: </Text>
    <Text style={styles.label}>Idade: {confirmIdade}</Text>
    <Text style={styles.label}>Sexo: {confirmSexo}</Text>
    <Text style={styles.label}>Escolaridade: {confirmEscolaridade}</Text>
    <Text style={styles.label}>Limite: {confirmLimite.toFixed(2)}</Text>
    <Text style={styles.label}>Brasileiro: {(confirmBrasileiro) ? "Sim" : "Não"}</Text>

  </View>
  );
}

export default App;

